SK KGN TEAM — Razorpay backend

Deploy this folder to Vercel.

Environment variables:
RAZORPAY_KEY_ID
RAZORPAY_KEY_SECRET
CALLBACK_TOKEN_SECRET
COMPLAINT_ENCRYPTION_SECRET

IMPORTANT:
In api/create-payment-link.js replace:
https://YOUR-VERCEL-DOMAIN.vercel.app/api/payment-callback
with your actual Vercel URL.

Do not put RAZORPAY_KEY_SECRET in index.html.
